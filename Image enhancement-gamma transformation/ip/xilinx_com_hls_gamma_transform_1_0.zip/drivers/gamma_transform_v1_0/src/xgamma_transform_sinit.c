// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xgamma_transform.h"

extern XGamma_transform_Config XGamma_transform_ConfigTable[];

XGamma_transform_Config *XGamma_transform_LookupConfig(u16 DeviceId) {
	XGamma_transform_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XGAMMA_TRANSFORM_NUM_INSTANCES; Index++) {
		if (XGamma_transform_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XGamma_transform_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XGamma_transform_Initialize(XGamma_transform *InstancePtr, u16 DeviceId) {
	XGamma_transform_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XGamma_transform_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XGamma_transform_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

