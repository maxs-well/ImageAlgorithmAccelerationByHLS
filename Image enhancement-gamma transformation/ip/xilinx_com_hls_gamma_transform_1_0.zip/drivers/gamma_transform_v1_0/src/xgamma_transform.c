// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xgamma_transform.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XGamma_transform_CfgInitialize(XGamma_transform *InstancePtr, XGamma_transform_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Axilites_BaseAddress = ConfigPtr->Axilites_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XGamma_transform_Start(XGamma_transform *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_AP_CTRL) & 0x80;
    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_AP_CTRL, Data | 0x01);
}

u32 XGamma_transform_IsDone(XGamma_transform *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XGamma_transform_IsIdle(XGamma_transform *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XGamma_transform_IsReady(XGamma_transform *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XGamma_transform_EnableAutoRestart(XGamma_transform *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_AP_CTRL, 0x80);
}

void XGamma_transform_DisableAutoRestart(XGamma_transform *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_AP_CTRL, 0);
}

void XGamma_transform_Set_rows(XGamma_transform *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_ROWS_DATA, Data);
}

u32 XGamma_transform_Get_rows(XGamma_transform *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_ROWS_DATA);
    return Data;
}

void XGamma_transform_Set_cols(XGamma_transform *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_COLS_DATA, Data);
}

u32 XGamma_transform_Get_cols(XGamma_transform *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_COLS_DATA);
    return Data;
}

void XGamma_transform_Set_gamma(XGamma_transform *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_GAMMA_DATA, Data);
}

u32 XGamma_transform_Get_gamma(XGamma_transform *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_GAMMA_DATA);
    return Data;
}

void XGamma_transform_Set_mode_V(XGamma_transform *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_MODE_V_DATA, Data);
}

u32 XGamma_transform_Get_mode_V(XGamma_transform *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_MODE_V_DATA);
    return Data;
}

void XGamma_transform_Set_fc(XGamma_transform *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_FC_DATA, Data);
}

u32 XGamma_transform_Get_fc(XGamma_transform *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_FC_DATA);
    return Data;
}

void XGamma_transform_InterruptGlobalEnable(XGamma_transform *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_GIE, 1);
}

void XGamma_transform_InterruptGlobalDisable(XGamma_transform *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_GIE, 0);
}

void XGamma_transform_InterruptEnable(XGamma_transform *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_IER);
    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_IER, Register | Mask);
}

void XGamma_transform_InterruptDisable(XGamma_transform *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_IER);
    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_IER, Register & (~Mask));
}

void XGamma_transform_InterruptClear(XGamma_transform *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XGamma_transform_WriteReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_ISR, Mask);
}

u32 XGamma_transform_InterruptGetEnabled(XGamma_transform *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_IER);
}

u32 XGamma_transform_InterruptGetStatus(XGamma_transform *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XGamma_transform_ReadReg(InstancePtr->Axilites_BaseAddress, XGAMMA_TRANSFORM_AXILITES_ADDR_ISR);
}

