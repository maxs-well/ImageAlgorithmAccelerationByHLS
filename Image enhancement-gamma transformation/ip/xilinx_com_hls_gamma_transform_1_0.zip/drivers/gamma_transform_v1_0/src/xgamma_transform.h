// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.1 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XGAMMA_TRANSFORM_H
#define XGAMMA_TRANSFORM_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xgamma_transform_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Axilites_BaseAddress;
} XGamma_transform_Config;
#endif

typedef struct {
    u32 Axilites_BaseAddress;
    u32 IsReady;
} XGamma_transform;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XGamma_transform_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XGamma_transform_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XGamma_transform_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XGamma_transform_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XGamma_transform_Initialize(XGamma_transform *InstancePtr, u16 DeviceId);
XGamma_transform_Config* XGamma_transform_LookupConfig(u16 DeviceId);
int XGamma_transform_CfgInitialize(XGamma_transform *InstancePtr, XGamma_transform_Config *ConfigPtr);
#else
int XGamma_transform_Initialize(XGamma_transform *InstancePtr, const char* InstanceName);
int XGamma_transform_Release(XGamma_transform *InstancePtr);
#endif

void XGamma_transform_Start(XGamma_transform *InstancePtr);
u32 XGamma_transform_IsDone(XGamma_transform *InstancePtr);
u32 XGamma_transform_IsIdle(XGamma_transform *InstancePtr);
u32 XGamma_transform_IsReady(XGamma_transform *InstancePtr);
void XGamma_transform_EnableAutoRestart(XGamma_transform *InstancePtr);
void XGamma_transform_DisableAutoRestart(XGamma_transform *InstancePtr);

void XGamma_transform_Set_rows(XGamma_transform *InstancePtr, u32 Data);
u32 XGamma_transform_Get_rows(XGamma_transform *InstancePtr);
void XGamma_transform_Set_cols(XGamma_transform *InstancePtr, u32 Data);
u32 XGamma_transform_Get_cols(XGamma_transform *InstancePtr);
void XGamma_transform_Set_gamma(XGamma_transform *InstancePtr, u32 Data);
u32 XGamma_transform_Get_gamma(XGamma_transform *InstancePtr);
void XGamma_transform_Set_mode_V(XGamma_transform *InstancePtr, u32 Data);
u32 XGamma_transform_Get_mode_V(XGamma_transform *InstancePtr);
void XGamma_transform_Set_fc(XGamma_transform *InstancePtr, u32 Data);
u32 XGamma_transform_Get_fc(XGamma_transform *InstancePtr);

void XGamma_transform_InterruptGlobalEnable(XGamma_transform *InstancePtr);
void XGamma_transform_InterruptGlobalDisable(XGamma_transform *InstancePtr);
void XGamma_transform_InterruptEnable(XGamma_transform *InstancePtr, u32 Mask);
void XGamma_transform_InterruptDisable(XGamma_transform *InstancePtr, u32 Mask);
void XGamma_transform_InterruptClear(XGamma_transform *InstancePtr, u32 Mask);
u32 XGamma_transform_InterruptGetEnabled(XGamma_transform *InstancePtr);
u32 XGamma_transform_InterruptGetStatus(XGamma_transform *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
